from def_api.routine.base import ObjectiveRoutine
from def_api.ttypes import DEFDouble, DEFInteger


class DemoObjectiveRoutine(ObjectiveRoutine):
    def __run__(self):
        # Fetch two parameters called 'param1' and 'param2'
        param1 = self.__get_parameter__('param1', DEFDouble()).value
        param2 = self.__get_parameter__('param2', DEFInteger()).value
        # ...

        # Some long running calculations based on the input parameters

        # Create result datatype and return it
        result = DEFInteger(value=5)
        return result
