from def_api.routine import run_routine
from demo_routines import DemoObjectiveRoutine

if __name__ == '__main__':
    run_routine(DemoObjectiveRoutine)
