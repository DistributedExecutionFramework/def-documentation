#!/bin/sh

zip -r routine_binary.pyz .